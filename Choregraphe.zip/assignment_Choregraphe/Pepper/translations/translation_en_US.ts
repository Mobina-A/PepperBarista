<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
    <context>
        <name>behavior_1/behavior.xar:/Animated Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Hello there</source>
            <comment>Text</comment>
            <translation type="obsolete">Hello there</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/BoyOrders/Say</name>
        <message>
            <source>Oh you were there? bummer. Just say what you need.</source>
            <comment>Text</comment>
            <translation type="obsolete">Oh you were there? bummer. Just say what you need.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/BoysOrder/Say</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Oh you were there? bummer. Just say what you need.</source>
            <comment>Text</comment>
            <translation type="unfinished">Oh you were there? bummer. Just say what you need.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/First/Animated Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/First/Say</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Hi, Welcome to Pepper's.</source>
            <comment>Text</comment>
            <translation type="unfinished">Hi, Welcome to Pepper's.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/GirlOrder/Say (1)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>As you are checking the menu, I should mention that the cake of the day suggested by the magnificent pepper is cinnamon roll.</source>
            <comment>Text</comment>
            <translation type="unfinished">As you are checking the menu, I should mention that the cake of the day suggested by the magnificent pepper is cinnamon roll.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Hi, Welcome to Pepper's.</source>
            <comment>Text</comment>
            <translation type="obsolete">Hi, Welcome to Pepper's.</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Great. I will bring the orders. </source>
            <comment>Text</comment>
            <translation type="unfinished">Great. I will bring the orders. </translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (1)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>As you are checking the menu, I should mention that the cake of the day suggested by the magnificent pepper is cinnamon roll.</source>
            <comment>Text</comment>
            <translation type="obsolete">As you are checking the menu, I should mention that the cake of the day suggested by the magnificent pepper is cinnamon roll.</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>I'm sorry for my mistake. I corrected it. </source>
            <comment>Text</comment>
            <translation type="unfinished">I'm sorry for my mistake. I corrected it. </translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (2)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Leave me alone mobina.</source>
            <comment>Text</comment>
            <translation type="obsolete">Leave me alone mobina.</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>your welcome.</source>
            <comment>Text</comment>
            <translation type="unfinished">your welcome.</translation>
        </message>
    </context>
</TS>
